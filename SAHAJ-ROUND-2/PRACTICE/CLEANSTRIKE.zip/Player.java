public class Player{
	int points, fouls, unPocketCount;  // attributes of players
	boolean won;
	public Player(){
		this.points = 0;
		this.fouls = 0;
		this.unPocketCount = 0;
		this.won = false;
	}
}