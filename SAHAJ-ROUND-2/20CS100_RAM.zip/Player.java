class Player{
    int points;
    int fouls;
    int didNotPocket;
    boolean prev;
    boolean won;
    public Player(){
        points = 1;
        fouls = 0;
        didNotPocket = 0;
        prev = false;
        won = false;
    }
}