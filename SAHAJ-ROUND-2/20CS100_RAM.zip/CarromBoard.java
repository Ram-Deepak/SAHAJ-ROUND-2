class CarromBoard{
    int totalCoins = 10;
    int blackCoins = 9;
    int redCoin = 1;
}