public class Board{
	int totalCoins, black, red;  // attributes of the board
	public Board(){
		this.totalCoins = 10;
		this.black = 9;
		this.red = 1;
	}
}